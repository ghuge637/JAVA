package arrayList;

import java.util.ArrayList;

public class Demo {
	public static void main(String[] args) {
		ArrayList l = new ArrayList();
		ArrayList l1 = new ArrayList();
		ArrayList l2 = new ArrayList();
		
		l.add(4);
		l.add("Vishal");
		l.add(null);
		l.add(6.1);
		l.add(true);
		l.add(120.120);
		
		l1.add(87);
		l1.add("Vishal");
		l1.add(null);
		
		l2.add("Yash");
		l2.add(7.86);
		l2.add(null);
		
		
		System.out.println(l.get(3));
		l.set(1, "Parth");  //Set metho for update the value in arrayList
		
		System.out.println(l);
		System.out.println("__________________________________________________");
		
		l.add(6, l1);  //use to add new element
		System.out.println(l);
		
		System.out.println("____________________________________________________");
		System.out.println(l.get(6));
		
		System.out.println("___________________________________________________");
		
		
		
		System.out.print("Index of: "+l.indexOf("Parth"));
	}
}
