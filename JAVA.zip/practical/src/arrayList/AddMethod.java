package arrayList;

import java.util.ArrayList;
import java.util.Scanner;

public class AddMethod {
	public static void main(String[] args) {
		ArrayList i = new ArrayList(); 
		
		i.add(11);  //All use to add
		i.add("Vishal");
		i.add('A');
		i.add(4.5);
		i.add(null);
		i.add(16);
		
		System.out.println(i);
		System.out.println("--------------------------");
		
		//addAll()
		ArrayList l1 = new ArrayList();
		l1.add(10);
		l1.add(null);
		l1.add("Vishal");
		l1.add('v');
		
		ArrayList l2 = new ArrayList();
		l2.add(11);
		l2.add(null);
		l2.add("Vishal Bhai");
		l2.add('g');
		
		System.out.println("ArrayList is: "+l1);
		System.out.println("----------------------------------");
		System.out.println("ArrayList is:"+l2);
		System.out.println("----------------------------------");

		
		l1.addAll(l2);//Use for add one list in another list
		System.out.println("AddAll() function OutPut: "+l1);
		l1.removeAll(l2);//Use for remove all List
		System.out.println("After use Remove all Method: "+l1);

		
		
		System.out.println("----------------------------------");
		ArrayList l3 = new ArrayList();
		
		
		String s = "Vishal";
		System.out.println("String Length: "+s.length());
		
		int[]a= {10,20,30,40};
		System.out.println("Array Length: "+a.length);
		
		System.out.println("ArrayList size: "+l1.size());
		
		System.out.println("----------------------------------------------------------");
		
		ArrayList l4 = new ArrayList(); //array List
//		Scanner sc = new Scanner(System.in);
//		System.out.print("Enter Array Size: ");
//		int size = sc.nextInt()-1;
//		
//		for(int i1=0; i1<=size; i1++) {
//			System.out.print("Enter List element: ");
//			l4.add(sc.next());
//		}
//		System.out.println(l4);
		l4.add(11);
		l4.add(null);
		l4.add("Vishal Bhai");
		l4.add('g');
		
		System.out.println("Show index location value using get(): "+l4.get(2));
		l4.remove(2);
		System.out.println("After remove: "+l4);
		
		ArrayList l5 = new ArrayList();
		
		l5.add(2);
		l5.add("v");
		l5.add(86);
		System.out.println(l5+" "+l5.contains(86)); //contains method --> use to find element
		
		System.out.println("--------------------------------------------------");
		ArrayList l6 = new ArrayList();
		l6.add(1);
		l6.add(2);
		l6.add(3);
		l6.add(4);
		
		ArrayList l7 = new ArrayList();
		l7.add(1);
		l7.add(2);
		l7.add(3);
		l7.add(4);
		
		System.out.println("contains methos check all arrayList is same or not: "+l7.containsAll(l6));
		
		System.out.println("___________________________________________________");
		ArrayList l8 = new ArrayList();
		System.out.println("Check arrayList isempty(): "+ l8.isEmpty()); //use to checkList is Empty
		
		System.out.println("_____________________________________________________________");
		
		System.out.println("Size of array List: "+l7.size()); //use to find array size
		
		System.out.println("_____________________________________________________________");
		System.out.println("iterator: "+l7.iterator());
	}
}
