package arrayList;

import java.util.ArrayList;
import java.util.Scanner;

public class FromUser {
	public static void main(String[] args) {
		ArrayList l4 = new ArrayList(); //array List
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter Array Size: ");
		int size = sc.nextInt()-1;
		
		for(int i1=0; i1<=size; i1++) {
			System.out.print("Enter List element: ");
			l4.add(sc.next());
		}
		System.out.println(l4);
	}
}
