package encapsulation;

import java.util.Scanner;

//class Encap{
//	private int num;
//	private String s;
//	
//	
//}
public class Ex1 {
	private int num;
	private String s;
	
	public void setnum(int num, String s) {
		this.num=num;
		this.s=s;
	}
	
	public int get() {
		return num;
	}
	
	public String getst() {
		return s;
	}
	
	public void display() {
		System.out.println("Name is: "+getst());
		System.out.println("Number is: "+get());
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the Name: ");
		String st = sc.nextLine();
		System.out.print(" Enter Number: ");
		int num = sc.nextInt();
		Ex1 e = new Ex1();
		e.setnum(num,st);
		e.display();
		
	}
}
