package encapsulation;

import java.util.Scanner;

public class Ex2 {
	private int num;
	private String s;
	private String auth;
	private double price;
	
	public void setnum(int num, String s,String auth,double price) {
		this.num=num;
		this.s=s;
		this.auth=auth;
		this.price=price;
	}
	
	public int getedition() {
		return num;
	}
	
	public String getname() {
		return s;
	}
	
	public String getauth() {
		return auth;
	}
	
	public double getprice() {
		return price;
	}
	
	public void display() {
		System.out.println("\nName is: "+getname());
		System.out.println("Author is: "+getauth());
		System.out.println("Price are: "+getprice());
		System.out.println("Edition is: "+getedition());
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the Name: ");
		String st = sc.next();
		
		System.out.println("Enter the author Name: ");
		String au = sc.next();
		
		System.out.print(" Enter Edition: ");
		int num = sc.nextInt();
		
		System.out.print("Enter the Price: ");
		double p = sc.nextDouble();
		
		Ex2 e = new Ex2();
		e.setnum(num,st,au,p);
		e.display();
		
	}
}
