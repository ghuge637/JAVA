package multyTherading;

import java.util.Scanner;

public class OddEven extends Thread{
	@Override
	public void run() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number to check Even Or not:"+Thread.currentThread().getName());
		int num = sc.nextInt();
		System.out.println(num%2==0?"Even Number":"Odd number"+Thread.currentThread().getName());	
	}
}
