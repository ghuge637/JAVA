package multyTherading;

public class Join {
	public static void main(String[] args) throws InterruptedException {
		OddEven o = new OddEven();
		PerfectNumber p = new PerfectNumber();
		
		p.start();
		p.join();
		o.start();
	}
}
