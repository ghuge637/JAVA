package linkedList;

import java.util.ArrayList;
import java.util.LinkedList;

public class Demo {
	public static void main(String[] args) {
		LinkedList l = new LinkedList();
		
		l.add(1);
		l.add("Vishal");
		l.add(null);
		
		ArrayList l2 = new ArrayList();
		
		l2.add(2);
		l2.add("parth");
		l2.add(8.7);
		
		System.out.println(l);
		System.out.println("___________________________________");
		l.remove(null);
		System.out.println(l);
		System.out.println("___________________________________");
		l.addAll(l2);
		System.out.println(l);
		
		System.out.println(l.contains("Vishal")); //check the element is present or not
		
		System.out.println("________________________________________________");
		System.out.println(l.contains(l2));
		
		System.out.println("___________________________________");
		l.removeAll(l2);
		System.out.println(l);
		System.out.println("___________________________________");
		
		l.clear();  
		System.out.println(l.isEmpty());
		
//		System.out.println();
	}
}
