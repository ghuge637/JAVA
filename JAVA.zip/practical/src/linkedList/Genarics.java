package linkedList;

import java.util.LinkedList;

public class Genarics {
	public static void main(String[] args) {
		LinkedList<String> l = new LinkedList<String>();
		
		l.add("Vishal");
		//l.add(1); --> it store only String datatype
		System.out.println(l);
	}
}
