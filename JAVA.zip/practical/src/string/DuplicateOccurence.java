package string;
import java.util.Scanner;


public class DuplicateOccurence {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter a string: ");
		String st = sc.nextLine();
		
		
		char[] charArray = st.toCharArray();
//		System.out.println(charArray[1]);

		for (int i = 0; i <= st.length(); i++) {
			
			char ch = '\0';
			char ch1= '\0';
			int count = 0;
             ch = st.charAt(i);

//            while(st.length()>0) {
            	
            	for (int j = 0; j < st.length(); j++) {
            		
            		ch1 = st.charAt(i);
            		
            		if(ch==ch1) {
            		count= count+ 1;
            			
            		}
//            	}
            } System.out.println("occurence of char is"+count);
        }            			

	}
}
