package string;

public class Demo {
	public static void main(String[] args) {
		String s1="Ram";
		String s2="Ran";
		
		String str1 = new String("Ram");
		
		System.out.println("Liters string:"+s1+s2);
		
		System.out.println("Object string:"+str1);
	}
}

