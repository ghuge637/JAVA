package string;
import java.util.Scanner;

public class Stringcheck {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter a string: ");
		String st1 = sc.nextLine();
		System.out.print("Enter a string2: ");
		String st2 = sc.nextLine();
		
		if(st1 == st2) {
			System.out.println("True");
		}
		else {
			System.out.println("False");
		}
		
		if(st1.equals(st2)) {
			System.out.println("True");
		}else {
			System.out.println("False");
		}
	}
}

//take one class car abstract 1. fule type
//normal 2. color
//tata class extend car
//abstraction class main method and create objects