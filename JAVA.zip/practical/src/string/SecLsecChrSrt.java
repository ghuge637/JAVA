package string;

import java.lang.reflect.Array;
import java.util.Scanner;

public class SecLsecChrSrt {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter a number: ");
		String st = sc.nextLine();
		char[] str= st.toCharArray();
		
		
		if(str[1]==str[st.length() - 2]) {
			
			System.out.println("Set");
		}else {
			System.out.println("Not-Set");
		}
	}
}
