package string;
import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter a number: ");
		String number = sc.nextLine();
		String paligdrom=" ";
		char ch;
		
//		System.out.println(number%10);
//		int num1 = number%10;
		
		for (int i = 0; i < number.length(); i++) {
          	
          
             ch = number.charAt(i);

            paligdrom = ch + paligdrom; 
        }
		
		if(paligdrom.equals(number)) {
			System.out.println("number is palingdrom");
		}
		else {
			System.out.println("number are not palingdrom");
		}	}
}
