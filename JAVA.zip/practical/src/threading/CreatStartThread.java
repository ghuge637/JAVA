package threading;

public class CreatStartThread extends Thread {
	
	@Override
	public void run() {
		System.out.println("My first Thread"+Thread.currentThread().getName());
	}
	
	public static void main(String[] args) {
		
		System.out.println("The Main method thread name check"+Thread.currentThread().getName());
		
		CreatStartThread c = new CreatStartThread();
		c.start(); // Creat Thread and run code
		
		//c.run() --> its only run the code
	}
}
