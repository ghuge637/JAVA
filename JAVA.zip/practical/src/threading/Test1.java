package threading;

public class Test1 {
	public static void main(String[] args) {
		Test2 t = new Test2();
		
		t.start();
		
		for(int i=0; i<=1000; i++) {
			System.out.println("Word");
		}
	}
}
