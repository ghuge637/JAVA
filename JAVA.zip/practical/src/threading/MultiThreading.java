package threading;

public class MultiThreading extends Thread {
	
	public static void Vishal() {
		System.out.println(Thread.currentThread().getName());
	}
	
	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName());
		Vishal();
	}

}
