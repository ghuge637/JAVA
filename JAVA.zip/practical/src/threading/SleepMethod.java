package threading;

import java.util.Scanner;

public class SleepMethod extends Thread{
	@Override
	public void run() {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter Start:");
		int s = sc.nextInt();
		System.out.println("Enter the End: ");
		int e = sc.nextInt();
		
		while(s<=e) {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println(s);
			s++;
		}
	}
	
	public static void main(String[] args) {
		SleepMethod  s = new SleepMethod();
		s.start();
	}

}
