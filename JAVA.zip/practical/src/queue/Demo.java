package queue;

public class Demo {

	//In the Queue Occure amiguity thats whay we can not code in que its only use in handriting
}
