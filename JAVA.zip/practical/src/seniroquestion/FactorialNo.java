package seniroquestion;

public class FactorialNo {
	public static void main(String[] args) {
		int num = 5;
		int fact1 = 1;
		int sum=0;
		
		while(num!=0) {
			int rem = num%10;
//			sum = sum+rem;
			num = num/10;
			
			for(int j=i; j>=i; j++) {
				fact1=fact1*j;
			}
		}
		
//		for(int i=1; i<=num; i++) {
//			
//			for(int j=i; j>=i; j++) {
//				fact1=fact1*j;
//			}
//			System.out.println(fact1);
//		}
	}
}
