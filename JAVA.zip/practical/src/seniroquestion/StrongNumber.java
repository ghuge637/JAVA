package seniroquestion;

import java.util.Scanner;

public class StrongNumber {
	public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number:");
		int num = sc.nextInt();
		int sum =0;
		int prod=0;
		
		while(num!=0) {
			
			int rem = num%10;
			sum =rem+sum;
			num/=10;
			 prod =rem*prod;
			 
			 for(int )
		}
		
		System.out.println(num==prod?"Yes":"No");
	}
}
