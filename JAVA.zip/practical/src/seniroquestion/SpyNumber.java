package seniroquestion;

import java.util.Scanner;

public class SpyNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number:");
		int num = sc.nextInt();
		int sum =0;
		int prod=1;
		
		while(num!=0) {
			
			int rem = num%10;
			sum =rem+sum;
			prod =rem*prod;
			num/=10;
			 
		}
		
		System.out.println(sum==prod?"Yes":"No");
	}
}
