package seniroquestion;

abstract class Car{
	
	public abstract void color();
}

class Tata extends Car{
	public void color(){
		System.out.println("Car color is Black");
	}
}

class Abstraction {

	public static void main(String args[]) {
		Tata t = new Tata();
		
		t.color();
	}
}
