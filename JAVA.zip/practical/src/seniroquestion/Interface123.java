package seniroquestion;
import java.util.Scanner;

interface Client{
	void input();
	void output();
}

class Vishal implements Client{
	int salary;
	String name = " ";

	@Override
	public void input() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter name: ");
		name = sc.nextLine();
		System.out.print("Enter Salary: ");
		salary = sc.nextInt();
		
	}

	@Override
	public void output() {
		// TODO Auto-generated method stub
		System.out.println(name);
		System.out.println(salary);
	}
	
}
public class Interface123 {
 public static void main(String[] args) {
	Vishal v = new Vishal();
	v.input();
	v.output();
}
}

