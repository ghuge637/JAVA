package seniroquestion;

import java.util.Scanner;

public class PerfectNumber {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number: ");
		int num = sc.nextInt();
		int sum=0;
			
			for(int j=1; j<num; j++) {
				
					if(num%j==0) {
						sum += j;
					}							 
				}
			
			System.out.println(sum==num?"Yes":"No");

	}
}
