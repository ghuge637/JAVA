//write a java program to get input from the user and check the even number is neon number or not
package seniroquestion;

import java.util.Scanner;

public class NeonNumber {
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter the number:");
		int num = sc.nextInt();
		int neo = num*num;
		int sum =0;
		
		while(neo!=0) {
			
			int rem = neo%10;
			sum =rem+sum;
			neo/=10;
		}
		
		System.out.println(num==sum?"Yes":"No");
	}
}
