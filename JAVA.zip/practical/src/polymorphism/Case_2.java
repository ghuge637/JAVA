package polymorphism;

public class Case_2 {

	void m1(Object o) {
		System.out.println("Object-version");
	}
	void m1(String s) {
		System.out.println("String-version");
	}
	
	public static void main(String[] args) {
		Case_2 o = new Case_2();
		
		o.m1(new Object());
		o.m1("vishal");
		o.m1(null);
	}
}
