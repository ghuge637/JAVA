package polymorphism;

public class Const {
	
	int a; double b; String c;
	
	Const(){
		a=100; b=23.3; c="Vishal";
	}
	
	Const(int x){
		a=x;
	}
	
	Const(double y, String s){
		b=y; c=s;
	}

	public static void main(String[] args) {
		Const r = new Const();
		Const r2 = new Const(10);
		Const r3 = new Const(12.54,"vishal");
		
		System.out.println(r.a+" " + r.b + " "+ r.c);
		
		System.out.println(r2.a);
		
		System.out.println(r3.b+" " +  " "+ r3.c);
		
	}
}
