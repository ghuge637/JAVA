package polymorphism;

class Property{
	void property() {
		System.out.println("Land + Mony");
	}
	
	void Marry() {
		System.out.println("Katrina");
	}
}

class Remarry extends Property{
	void Marry() {
		System.out.println("Priyanka");
	}
}

public class overriding {
	public static void main(String[] args) {
		Property p = new Property();
		p.Marry();
		Remarry r = new Remarry();
		r.Marry();
		
		Property a = new Remarry();
		a.Marry();
	}
}
