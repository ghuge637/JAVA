package polymorphism;

public class Case_4 {
   
	void m1(int s) {
		System.out.println("general method");
	}
	
	void m1(int ...i) {
		System.out.println("var-arg Method");
	}
	
	public static void main(String[] args) {
		Case_4 o = new Case_4();
		o.m1();
		o.m1(10,43);
	}
}
