package polymorphism;

class Animal{
	
}
class Monky extends Animal{
	
}
public class Case_5 {
	void m1(Animal a) {
		System.out.println("Animal version");
	}
	
	void m1(Monky a) {
		System.out.println("monkey version");
	}
	
	
	public static void main(String[] args) {
		Case_5 c = new Case_5();
		Animal a = new Animal();
		c.m1(a);
		Monky m = new Monky();
		c.m1(m);
		
		Animal a1 = new Monky();
		c.m1(a1);
	}
}
