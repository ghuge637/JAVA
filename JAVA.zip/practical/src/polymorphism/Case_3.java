package polymorphism;

public class Case_3 {
   
	void m1(String s) {
		System.out.println("string-version");
	}
	
	void m1(StringBuffer s) {
		System.out.println("Buffer-version");
	}
	
	public static void main(String[] args) {
		Case_3 o = new Case_3();
		//o.m1(null); // it give error
	}
}
