package polymorphism;

public class overloading {
	
	int add(int a, int b) {
		return a+b;
	}
	
	double add(double a, double b) {
		return a+b;
	}
	
	int add(int a, int b, int c) {
		return a+b+c;
	}

	
	public static void main(String[] args) {
		overloading o = new overloading();
		
		System.out.println(o.add(2, 6));
		System.out.println(o.add(2.7, 9.1));
		System.out.println(o.add(1, 4, 6));
	}
}

