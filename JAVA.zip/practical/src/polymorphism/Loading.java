package polymorphism;


public class Loading {
	
	public void m1(int i) {
		System.out.println("I am int");
	}
	

public void m1(float i) {
	System.out.println("I am float");
}


	public static void main(String[] args) {
		
		Loading lo = new Loading();
		
		lo.m1(4);
		lo.m1(10.5f);
		lo.m1('a');
		lo.m1(10l);
//		lo.m1(10.5);  //can not do any promation thats why it give error
		
		//byte -> short ->
		//                  int -> long -> float -> double
		//        char ->
	}
}
