package abstraction;

import java.util.Scanner;

public class User extends Atm {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		Bank a = new Atm();  //upcating --> refrence class hide back of interface:-> give interface name

		
		System.out.println("Enter ID: ");
		if(sc.nextInt()==Bank.account) {
			
			System.out.println("Enter Password: ");
			if(sc.next().equals(Bank.pass)) {
				
		
		while(true) {
			System.out.println("1. Enter for Deposite: ");
			System.out.println("2. Enter for Withdeow: ");
			System.out.println("3. Enter for Display: ");
			System.out.println("4. Logout ");
			System.out.println("Enter your choice: ");
			int choice = sc.nextInt();
		
		
		switch(choice) {
		
		case 1:
			System.out.print("Enter Amount for deposite: ");
			double num = sc.nextDouble();
			a.deposite(num);
			break;
			
		case 2:
			System.out.print("Enter Amount for withdrow: ");
			double num1 = sc.nextDouble();
			a.withdrow(num1);
			break;
			
		case 3:
			a.display();
			break;
			
		case 4:
			System.out.println("Logout");
			System.exit(0);
			}
		}
	}
	 else {
			System.out.println("Wrong Password..!");
		}
	}
		else {
		System.out.println("Wrong ID..!");
	}
}
	
}
