package abstraction;

public interface Bank {
	final int account=123;
	final String pass = "pass123";
	void withdrow(double balance);
	void deposite(double balance);
	void display();
}
