package abstraction;

public class Atm implements Bank {
    double acc;
	@Override
	public void withdrow(double amount) {
		// TODO Auto-generated method stub
		if(acc> 0) {
			acc = acc - amount;
		}else {
			System.out.println("Your account is empty..!!");
		}
	}

	@Override
	public void deposite(double amount) {
		// TODO Auto-generated method stub
		acc += amount;
		System.out.println("Amount is Deposited..!");
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("Remaning amount is: "+acc);
	}
	
		
}
