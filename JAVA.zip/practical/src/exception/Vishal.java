package exception;

public class Vishal extends Exception {
	public void m1() {
		System.out.println("Incorrect Id");
	}
	
	public void m2() {
		System.out.println("Incorrect Password");
	}
}
