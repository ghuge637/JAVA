package exception;

import java.util.Scanner;

public class Demo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter 1st Number: ");
		int num1 = sc.nextInt();
		System.out.println("Enter 2nd Number");
		int num2 = sc.nextInt();
		
		try {
			System.out.println("Output is: "+ (num1/num2));
		}
		
//		catch(ArithmeticException e){
//			System.out.println("Not Valid");
//		}
		
//		catch(Throwable e){
//			System.out.println("Not Valid");
//		}
		
//		catch(Exception e){
//			System.out.println("Not Valid");
//		}
		
		catch(RuntimeException e){
			System.out.println("Invalid Operation");
			System.out.println("-------------------------------------------");
			System.out.println("Exception name");
			e.printStackTrace();
			System.out.println("-------------------------------------------");
			System.out.println("Not Valid " + e.getMessage());  // show why error occure
		}
		
		System.out.println("End");
		
	}
}
