package exception;

import java.util.Scanner;

public class Bank {
	public static void main(String[] args) throws Vishal {
		int id = 123;
		int pass = 111;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Id: ");
		if(sc.nextInt()==id) {
			
			System.out.println("Enter the pass: ");
			if(sc.nextInt()==pass) {
				System.out.println("Login");
			}
			else {
				Vishal v = new Vishal();
				v.m2();
				throw v;
			}
		}
		else {
			Vishal v = new Vishal();
			v.m1();
			throw v;
		}
	}
}
