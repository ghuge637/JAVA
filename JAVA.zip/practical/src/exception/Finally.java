package exception;

import java.util.Scanner;

public class Finally {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number: ");
		int num1 = sc.nextInt();
		System.out.println("Enter the second number: ");
		int num2 = sc.nextInt();
		
		try {
			System.out.println("OutPut: " + (num1/num2));
		}
		catch(RuntimeException e){
			System.out.println("Invalid Operation");
			System.out.println("-------------------------------------------");
			System.out.println("Exception name");
			e.printStackTrace();
			System.out.println("-------------------------------------------");
			System.out.println("Not Valid " + e.getMessage());  // show why error occure
			System.exit(0);
		}
		finally{
			System.out.println(" Final block");
			
		}
		
		System.out.println("End");
	}
}
