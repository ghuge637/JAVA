package exception;

public class ArrayOutOfBound {
	public static void main(String[] args) {
		int[] arr = {2,3,4};
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		
		try {
			System.out.println(arr[3]);
		} 
		catch(Exception e) {
			System.out.println("Array out of bound");
			System.out.println("-------------------------------");
			e.printStackTrace();
			System.out.println("-----------------------------------");
			System.out.println("Exception:" + e.getMessage());
		}
	}
}
