package exception;

public class IntruptException {
	
	static void m1() throws InterruptedException {
		for(int i=0; i<=4; i++) {
			Thread.sleep(1000);
			System.out.println(i);
			
		}
	}
	
	public static void main(String[] args) {
		try {
			m1();
		} catch (Exception e) {
			System.out.println(e.getMessage());// Ambiguty error
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	}
}
