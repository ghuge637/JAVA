package objectClasses;

public class Equals {
	int a;
	Equals(int a){
		this.a=a;
	}
	
	public boolean equals(Equals obj) { //upcast
		Equals e2 = (Equals) obj;  //down cast
		return this.a == e2.a;
	}
	
	public static void main(String[] args) {
		Equals e = new Equals(1);
		Equals e1 = new Equals(1);
		
		System.out.println(e==e1?"Same":"Not-same");
		
		System.out.println(e.equals(e1)?"Same":"Not-same");
	}
}
