package objectClasses;

public class Object {

}
