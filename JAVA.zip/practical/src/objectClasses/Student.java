package objectClasses;

public class Student {  // To String Method overriding
	String name;
	
	Student(String name){
		this.name=name;
	}
	
	public String toString()
	{ 
		return this.name;
	}
	
	public static void main(String[] args) {
		Student s1 = new Student("Tom");
		Student s2 = new Student("jerry");
		
		
		System.out.println(s1);
		System.out.println(s2);
	}
}
