package objectClasses;

public class HashCode {   // Implicitly extends propertys of object class 
	int num;
	HashCode(int num){
		this.num = num;
	}
	
	public int hashCode() {
		return 1;
	}
	
	public static void main(String[] args) {
		HashCode h = new HashCode(10);
		
		System.out.println(h);
		System.out.println(h.hashCode());
	}
}
