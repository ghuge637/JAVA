package superThisCall;

public class Son extends Father {
	public Son(int a) {
		super(3.4f);
		System.out.println("Son constructor");
	}
	public static void main(String[] args) {
		Son s = new Son(19);
	}
}
