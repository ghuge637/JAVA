package superThisCall;

public class Father extends GrandPa {
	public Father(float a){
		
		super("ram");
		System.out.println("Father constructor");
	}
}
