package superThisCall;

public class GrandPa {
	
	public GrandPa(String name) {
		
		System.out.println("grandfather constructor");
	}
}
