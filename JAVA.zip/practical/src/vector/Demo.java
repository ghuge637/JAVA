package vector;

import java.util.Vector;

public class Demo {
	public static void main(String[] args) {
		Vector v = new Vector();  // Vector store only 10 Elements
		
		v.add("Vishal");
		v.add(10);
		v.add(null);
		v.add(87);
		
		System.out.println(v);
	}
}
