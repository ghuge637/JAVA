package autobox_autoUnbox;

public class AutoBox {
	public static void main(String[] args) {
		int a = 10;
		
		Integer i = new Integer(a);  //Auto Boxing --> it convert primative data type into non-primative datatype
		System.out.println(i);
		
		int b = i; //Auto UnBoxing --> its convert no-primative data to primative data
	}
}
