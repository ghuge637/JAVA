package autobox_autoUnbox;

import java.util.ArrayList;

public class ForEach {
	public static void main(String[] args) {
		int []a= {10,20,30};
		
		for(int x:a) {
			System.out.println(" "+x);
		}
		
		ArrayList l = new ArrayList();
		l.add(1);
		l.add("Vishal");
		l.add(null);
		l.add(4.9);
		
		System.out.print("ArrayList print Using Object: ");
		for(Object o:l) {
			System.out.print(o+", ");
		}
	}
}
