package tree_set;

import java.util.TreeSet;

public class Demo {
	public static void main(String[] args) {  // It alwasa follow sorted order
		TreeSet t = new TreeSet();
		
		t.add(20);
		t.add(10);
		t.add(60);
		t.add(0);
		t.add(3);
		
		System.out.println(t);
	}
}
