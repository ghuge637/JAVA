package set;

import java.util.LinkedHashSet;

public class Link_Hash_Set {
	public static void main(String[] args) {
		LinkedHashSet lh = new LinkedHashSet();   // It follows doubly-Linked List
		
		lh.add("Vishal");
		lh.add(1);
		lh.add(null);
		
		System.out.println(lh);
	}
}
