package set;

import java.util.HashSet;

public class Hash_set {
	public static void main(String[] args) {  // Initial Capicity is 16 --> Increment = IC + IC(0.75%)
		HashSet h = new HashSet();    // It not Follow Insertion order or index numbers
		
		h.add("Vishal");
		h.add(null);
		h.add(98);
		
		System.out.println(h);
	}
}


/* --> 1 set dosent allow duplicate but list allows duplicate
   --> set is not index based but list is index based 
   --> we can insert into the set become insert null into list
   --> HastSet internally follows */