/*. Write a Java program that defines a Student class and demonstrates
method overloading using non-static methods
 The program should:
 Prompt the user to enter student details (name and roll number)
 Create a Student class with the following non-static methods
 display(String name) – accepts and displays the student's
name
 display(int rollNumber) – accepts and displays the
student's roll number
 display() – a non-parameterized method that simply
displays a message like "Student details displayed above
 Call all three methods from the main() method
 Demonstrate method overloading by using the same method
name display() with different parameter lists*/
package assignment;

public class Q5 {

}
