/*Write a Java program that uses three classes: ATM, Bank, and User
 Use encapsulation by declaring data members as private in the
ATM and User classes
 Provide getter and setter methods for accessing and modifying
those private members
 The Bank class should act as the mediator that processes and
displays ATM transactions for a user
 Use constructors and method calls to simulate a simple
transaction (like balance check or withdrawal)
 Requirements:
 User class:
 Private data members: userName, pin, balance
 Getter and setter methods for all fields
 ATM class:
 Private data member: atmId
 Getter and setter for atmId
 Bank class
 Has methods to perform actions like showing user
details and simulating balance check or withdrawal
 Demonstrate the interaction among the classes in
the main() method*/
package assignment;

public class Q7 {

}
