/*Write a Java program to check whether a given integer number is odd
or even
 Constraints:
 Do not use if-else statements
 Do not use arrays, strings, or any inbuilt Java methods
(e.g., Math, Arrays, Integer, etc.).*/
package assignment;

public class Q8 {

}
