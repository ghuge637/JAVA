/*.Write a Java program that:
 Accepts a string input from the user.
 Accepts a substring input to search for
 Checks whether the main string contains the given substring
 Prints a clear message indicating if the substring is present or
not. Use appropriate string methods to perform the check*/
package assignment;

public class Q10 {

}
