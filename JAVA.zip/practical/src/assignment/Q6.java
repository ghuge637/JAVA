/*Write a Java program that demonstrates the Has-A (association)
relationship using four classes
 Vehicle (Base class — contains general vehicle information like
brand)
 Bike (Represents a bike, e.g., model "Hornet")
 Car (Represents a car, e.g., model "Civic")
 Honda (Main class that "has-a" Bike and Car objects,
representing Honda's vehicles)
 Requirements:
 Use constructors to initialize non-static data members
 Establish Has-A relationships (i.e., Honda has a Bike and
has a Car)
Display all relevant information using appropriate display()
methods.*/
package assignment;

public class Q6 {

}
