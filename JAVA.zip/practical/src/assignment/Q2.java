/*Write a Java program that takes a string input from the user and
checks whether the second character and the second last character of
the string are the same
 Prompt the user to enter a string
 Check if the string has at least 2 characters
 Compare the second character (index 1) and the second last
character (index length - 2)
 Display whether they are the same or not*/
package assignment;

public class Q2 {

}
