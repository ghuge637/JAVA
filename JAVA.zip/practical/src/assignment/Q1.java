/* Write a Java program that takes an integer input as number from the
user, then finds and displays the second largest digit in the number.
 Accept a positive integer from the user.
 Identify and display the second largest digit
 If there is no second largest digit (e.g., all digits are the same),
display an appropriate message.
 */
package assignment;

import java.util.Scanner;

public class Q1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
	}
}
