/*9. Write a Java program that:
 Accepts two strings as input from the user
 Checks whether the two strings are anagrams of each other
 Ignores case and spaces while checking
 Prints a clear message about whether the strings are anagrams
or not
 Implement the anagram logic yourself (without using built-in
sort methods)*/
package assignment;

public class Q9 {

}
