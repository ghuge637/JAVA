/*Write a Java program that takes a string and a character as input from
the user, and counts how many times the character appears in the
string
 Prompt the user to enter a string
 Prompt the user to enter a single character.
 Count and display how many times the character appears in the
string
 Handle both uppercase and lowercase comparisons (caseinsensitive comparison
 Validate that the user enters exactly one character*/
package assignment;

public class Q3 {

}
