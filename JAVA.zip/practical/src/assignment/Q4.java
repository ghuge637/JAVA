/*Write a Java program that demonstrates the use of static and nonstatic methods to perform various number-based checks
 Requirements : Create a class that includes
 Non-static methods for :
 Checking whether a number is an Armstrong number
 Checking whether a number is a Strong number
 Static methods for :
 Checking whether a number is Odd or Even
 Checking whether a number is Prime
 Checking whether a number is a Perfect number
 Use a switch-case menu to allow the user to select which
operation to perform
 Prompt the user to enter the number to be tested based on the
selected operation
 Display the result of the check*/
package assignment;

public class Q4 {

}
