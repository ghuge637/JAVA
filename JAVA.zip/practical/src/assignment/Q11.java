/*Write a java program to count Duplicate occurences of charactor from the given string*/
package assignment;

import java.util.Scanner;

public class Q11 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String name = sc.next();
		char ch;
		
		for(int i=0; i<=name.length(); i++) {
			ch =
		}
	}
}
