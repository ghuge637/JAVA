package singleton;

public class Bank {
	private static Bank b = null;
	private Bank() {
		System.out.println("Object created");
	}

	public static void m1() {
		if(b==null) {
			b = new Bank();	
		}
		else {
			System.out.println("Object already exist");
		}
	}
}
