package singleton;

public class User {
	public static void main(String[] args) {
		Bank.m1();
		Bank.m1();
	}
}
