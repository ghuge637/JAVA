//to count upper case and lowercase leter in given string
package practice;
import java.util.*;

public class Checkstring {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	String st = " ";
	int count = 0;
	int low = 0;
	
	System.out.println("Enter a String");
	st = sc.nextLine();
	
	System.out.println(st);
	for(int i=0; i<st.length(); i++) {
		char ch = st.charAt(i);
//		
		
		if(Character.isUpperCase(ch)) {
			count += 1;
		}
		else {
			low += 1;
		}
	}
	
	System.out.println("Upper case later is: "+ count);
	System.out.println("Lower case laters is: "+low);
	
}
}

