package practice;

import java.util.Scanner;

public class OneToThousendArmstrong {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the Number to find Armstrong Numbers from 1 to n: ");
		int n1 = sc.nextInt();
		
		System.out.println("Given All Numbers Are Armstrong Number between 1 to "+n1);
		for(int j=1; j<=n1; j++) {
			int num = j;
			int num1 = num;
			int input = num;
			int count = 0;
			int sum = 0;
			
			while(num != 0) {
				int n = num%10;
				count = count+1;
				num = num/10;
			}
			
			while(num1 != 0) {
				int n = num1%10;
				num1 = num1/10;
				
				int pro = 1;
				for(int i=1; i<=count; i++) {
					pro = pro*n;
				}
				sum = sum+pro;
			} 
			if(input == sum) {
				System.out.println(sum);
			}
		}
	}
}
