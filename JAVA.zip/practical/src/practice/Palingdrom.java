//write a java program to check given number palingdrom or not and also find palingdrom next and previous number of that number
package practice;
import java.util.Scanner;

public class Palingdrom {
	


//Palingdrom number..........................................................
	public static void palingDo(int num) {
		int reminder, temp, revers=0;
		temp=num;
		
		while(temp>0) {
			reminder = temp%10;
			revers = revers*10+reminder;
			temp = temp/10;
		}
		
		if(revers == num) {
			System.out.println("Number is Palindrom");
		}
		else {
			System.out.println("Number is not Palindrom");
		}
		
	}
	
//next Number..............................................................
		public static void next(int num) {
			
			int temp=num;
			int number = num;
			while(true) {
				number++;
				
				temp = number;
				int reminder = 0;
				int revers = 0;
				
				while(temp>0) {
					reminder = temp%10;
					revers = revers*10+reminder;
					temp = temp/10;
				}
				
				if(revers == number) {
					System.out.println("Next number is: "+ number);
					break;
				}
				
			}
		}
	
//previous Number..................................................................
		public static void pre(int num) {
			int reminder, temp, revers=0;
			int number2 = num;
			while(true) {
				number2--;
				
				temp = number2;
				reminder = 0;
				revers = 0;
				
				while(temp>0) {
					reminder = temp%10;
					revers = revers*10+reminder;
					temp = temp/10;
				}
				
				if(revers == number2) {
					System.out.println("priouse number is: "+ number2);
					break;
				}
				
			}
		}
		
		
//main method..............................................................................
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.print("Enter a number: ");
		int number = sc.nextInt();
		
		palingDo(number); //Call the method for check number is palingdrom or not
		next(number);     //Findout next Palingdrom number
		pre(number);      //Finding prious palingdrom number
		
		}
}
