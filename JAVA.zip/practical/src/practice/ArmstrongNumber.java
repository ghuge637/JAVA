package practice;

import java.util.Scanner;

public class ArmstrongNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the Number: ");
		int num = sc.nextInt();
		int num1 = num;
		int input = num;
		int count = 0;
		int sum = 0;
		
		while(num != 0) {
			int n = num%10;
			count = count+1;
			num = num/10;
		}
		
		while(num1 != 0) {
			int n = num1%10;
			num1 = num1/10;
			
			int pro = 1;
			for(int i=1; i<=count; i++) {
				pro = pro*n;
			}
			sum = sum+pro;
		}
		System.out.println(input == sum?"Yes it is Armstrong Number":"NO its NOT-Armstrong Number");
	}
}
