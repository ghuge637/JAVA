package practice;

import java.util.Scanner;

public class ZyloemNO {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
       
        System.out.print("Enter the number: ");
        int num=sc.nextInt();
        
		int last = num%10;
		num=num/10;
		int sum = 0;
		
		while(num>9) {
			int rem = num%10;
			sum = sum+rem;
			num = num/10;
		}
		
		System.out.println((num+last)==sum?"Number is Zyloem":"Number is ployem");
		
	}
}

