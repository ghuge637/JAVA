package practice;


public class ThisKey {
	String s = "Global variable";
	public void m1() {
		String s = "Local variable";
		System.out.println(s);
		System.out.println(this.s);
	}

	public static void main(String[] args) {
		
		ThisKey obj = new ThisKey();
		obj.m1();
	}
}
