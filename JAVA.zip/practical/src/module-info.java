/**
 * 
 */
/**
 * 
 */
module practical {
}