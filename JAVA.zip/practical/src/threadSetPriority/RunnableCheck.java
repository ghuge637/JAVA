package threadSetPriority;

public class RunnableCheck implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("My thread: Through: Runnable Interface");
	}
	
	public static void main(String[] args) {
		RunnableCheck r = new RunnableCheck();
		
		Thread t = new Thread(r); //This is Narrowing
		t.start();
	}
}
