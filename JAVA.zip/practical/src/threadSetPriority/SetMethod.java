package threadSetPriority;

public class SetMethod extends Thread {
	
	SetMethod(String name){
		super(name);    //asign Name to threads
	}
	
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()+Thread.currentThread().getPriority()+" "+Thread.currentThread().getId());
	}
	
	public static void main(String[] args) {
		SetMethod s = new SetMethod("EHigh");
		SetMethod s1 = new SetMethod("High");
		SetMethod s2 = new SetMethod("Mid");
		SetMethod s3 = new SetMethod("Low");
		
		s.setPriority(MAX_PRIORITY);  //Thread can not set --> set using DSA
		s.start();
		s.setPriority(NORM_PRIORITY);
		s1.start();
		s.setPriority(MIN_PRIORITY);
		s2.start();
		
		//s3.start();
	}
}
