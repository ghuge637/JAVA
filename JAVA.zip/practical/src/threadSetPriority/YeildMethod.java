package threadSetPriority;

public class YeildMethod extends Thread {
	
	YeildMethod(String name){
		super(name);
	}
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()+" "+Thread.currentThread().getPriority());
	}
	public static void main(String[] args) {
		YeildMethod y = new YeildMethod("Max");
		YeildMethod y1 = new YeildMethod("mid");
		YeildMethod y2 = new YeildMethod("min");
		
//		y.setPriority(MAX_PRIORITY);
		y.start();
		
		Thread.yield();
		y1.setPriority(MAX_PRIORITY);
		y1.start();
		
		y2.setPriority(MIN_PRIORITY);
		y2.start();
	}
}
