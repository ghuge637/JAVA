package threadSetPriority;

public class InteruppedThread extends Thread{
	
	@Override
	public void run() {
		for(int i=1; i<=5; i++) {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(i);
		}
	}
	
	public static void main(String[] args) {
		InteruppedThread i = new InteruppedThread();
		
		i.run();
	}
}
