package threadSetPriority;

public class SetDaemon extends Thread{
	@Override
	public void run() {
		for(;;) {
			System.out.println("Hello");
		}
	}
	
	public static void main(String[] args) {
		SetDaemon s = new SetDaemon();
		
		s.setDaemon(true);
		s.start();
		System.out.println(Thread.currentThread().getName());
	}
	
}
